[![Tests](https://github.com/mattyocode/hypermodern-python-tutorial/workflows/Tests/badge.svg)](https://github.com/mattyocode/hypermodern-python-tutorial/actions?workflow=Tests)
[![codecov](https://codecov.io/gh/mattyocode/hypermodern-python-tutorial/branch/main/graph/badge.svg?token=H8B46Y497K)](https://codecov.io/gh/mattyocode/hypermodern-python-tutorial)
[![PyPI](https://img.shields.io/pypi/v/hypermodern-tutorial.svg)](https://pypi.org/project/hypermodern-python/)


# Working through Hypermodern Python tutorial/walk through

Tutorial found at: https://cjolowicz.github.io/posts/hypermodern-python-01-setup/
